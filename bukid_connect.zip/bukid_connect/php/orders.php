<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success'=>false,'message'=>'Not authenticated.']); exit;
    }
}

// ── PLACE ORDER ────────────────────────────────────────────
if ($action === 'place_order') {
    requireLogin();
    if ($_SESSION['role'] !== 'buyer') { echo json_encode(['success'=>false,'message'=>'Buyers only.']); exit; }

    $buyer_id  = $_SESSION['user_id'];
    $crop_id   = (int)($_POST['crop_id'] ?? 0);
    $qty       = (float)($_POST['quantity'] ?? 0);
    $dtype     = in_array($_POST['delivery_type'] ?? '', ['pickup','delivery']) ? $_POST['delivery_type'] : 'pickup';
    $daddr     = sanitize($conn, $_POST['delivery_address'] ?? '');
    $notes     = sanitize($conn, $_POST['notes'] ?? '');
    $otype     = in_array($_POST['order_type'] ?? '', ['instant','pre-order']) ? $_POST['order_type'] : 'instant';

    // Get crop details
    $res = $conn->query("SELECT * FROM crops WHERE id=$crop_id AND status IN ('available','pre-order')");
    if ($res->num_rows === 0) { echo json_encode(['success'=>false,'message'=>'Crop not found or unavailable.']); exit; }
    $crop = $res->fetch_assoc();

    if ($qty <= 0 || $qty > $crop['quantity_available']) {
        echo json_encode(['success'=>false,'message'=>'Invalid quantity.']); exit;
    }

    $total = $qty * $crop['price_per_unit'];
    $farmer_id = $crop['farmer_id'];

    $stmt = $conn->prepare("INSERT INTO orders (buyer_id,farmer_id,crop_id,quantity,total_price,order_type,delivery_type,delivery_address,notes) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param("iiiddsss", $buyer_id, $farmer_id, $crop_id, $qty, $total, $otype, $dtype, $daddr, $notes);
    // Update crop quantity
    $new_qty = $crop['quantity_available'] - $qty;
    $new_status = $new_qty <= 0 ? 'sold_out' : $crop['status'];

    if ($stmt->execute()) {
        $conn->query("UPDATE crops SET quantity_available=$new_qty, status='$new_status' WHERE id=$crop_id");
        echo json_encode(['success'=>true,'message'=>'Order placed successfully!','total'=>$total]);
    } else {
        echo json_encode(['success'=>false,'message'=>'Order failed.']);
    }
    exit;
}

// ── GET MY ORDERS (buyer) ──────────────────────────────────
if ($action === 'my_orders') {
    requireLogin();
    $uid  = $_SESSION['user_id'];
    $role = $_SESSION['role'];
    $col  = $role === 'buyer' ? 'o.buyer_id' : 'o.farmer_id';

    $sql = "SELECT o.*, c.crop_name, c.unit, c.image,
            ub.full_name AS buyer_name, uf.full_name AS farmer_name
            FROM orders o
            JOIN crops c ON o.crop_id=c.id
            JOIN users ub ON o.buyer_id=ub.id
            JOIN users uf ON o.farmer_id=uf.id
            WHERE $col=$uid ORDER BY o.created_at DESC";

    $res = $conn->query($sql);
    $orders = [];
    while ($row = $res->fetch_assoc()) $orders[] = $row;
    echo json_encode(['success'=>true,'orders'=>$orders]);
    exit;
}

// ── UPDATE ORDER STATUS (farmer) ───────────────────────────
if ($action === 'update_order') {
    requireLogin();
    $id     = (int)($_POST['id'] ?? 0);
    $status = sanitize($conn, $_POST['status'] ?? '');
    $uid    = $_SESSION['user_id'];
    $valid  = ['confirmed','packed','in_transit','delivered','cancelled'];
    if (!in_array($status, $valid)) { echo json_encode(['success'=>false,'message'=>'Invalid status.']); exit; }
    $conn->query("UPDATE orders SET status='$status' WHERE id=$id AND farmer_id=$uid");
    echo json_encode(['success'=>true,'message'=>'Order status updated.']);
    exit;
}

// ── GET ALL ORDERS (admin) ─────────────────────────────────
if ($action === 'all_orders') {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') { echo json_encode(['success'=>false,'message'=>'Admin only.']); exit; }

    $sql = "SELECT o.*, c.crop_name, ub.full_name AS buyer_name, uf.full_name AS farmer_name
            FROM orders o
            JOIN crops c ON o.crop_id=c.id
            JOIN users ub ON o.buyer_id=ub.id
            JOIN users uf ON o.farmer_id=uf.id
            ORDER BY o.created_at DESC LIMIT 100";

    $res = $conn->query($sql);
    $orders = [];
    while ($row = $res->fetch_assoc()) $orders[] = $row;
    echo json_encode(['success'=>true,'orders'=>$orders]);
    exit;
}

echo json_encode(['success'=>false,'message'=>'Unknown action.']);
?>
