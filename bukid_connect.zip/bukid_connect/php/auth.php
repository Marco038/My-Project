<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$action = $_POST['action'] ?? '';

// ── REGISTER ──────────────────────────────────────────────
if ($action === 'register') {
    $username  = sanitize($conn, $_POST['username'] ?? '');
    $email     = sanitize($conn, $_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $role      = in_array($_POST['role'] ?? '', ['farmer','buyer']) ? $_POST['role'] : 'buyer';
    $full_name = sanitize($conn, $_POST['full_name'] ?? '');
    $phone     = sanitize($conn, $_POST['phone'] ?? '');
    $address   = sanitize($conn, $_POST['address'] ?? '');

    if (!$username || !$email || !$password) {
        echo json_encode(['success'=>false,'message'=>'All fields required.']); exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success'=>false,'message'=>'Invalid email.']); exit;
    }
    if (strlen($password) < 8) {
        echo json_encode(['success'=>false,'message'=>'Password must be at least 8 characters.']); exit;
    }

    $check = $conn->query("SELECT id FROM users WHERE username='$username' OR email='$email'");
    if ($check->num_rows > 0) {
        echo json_encode(['success'=>false,'message'=>'Username or email already exists.']); exit;
    }

    $hashed = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO users (username,email,password,role,full_name,phone,address) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssss", $username, $email, $hashed, $role, $full_name, $phone, $address);

    if ($stmt->execute()) {
        $uid = $conn->insert_id;
        $conn->query("INSERT INTO audit_logs (user_id,action,details,ip_address) VALUES ($uid,'REGISTER','New user registered: $username','".$_SERVER['REMOTE_ADDR']."')");
        echo json_encode(['success'=>true,'message'=>'Account created! Please login.']);
    } else {
        echo json_encode(['success'=>false,'message'=>'Registration failed.']);
    }
    exit;
}

// ── LOGIN ─────────────────────────────────────────────────
if ($action === 'login') {
    $username = sanitize($conn, $_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
        echo json_encode(['success'=>false,'message'=>'Username and password required.']); exit;
    }

    $res = $conn->query("SELECT * FROM users WHERE (username='$username' OR email='$username') AND is_active=1");
    if ($res->num_rows === 0) {
        echo json_encode(['success'=>false,'message'=>'Invalid credentials.']); exit;
    }

    $user = $res->fetch_assoc();

    // Lockout check
    if ($user['lockout_until'] && strtotime($user['lockout_until']) > time()) {
        $mins = ceil((strtotime($user['lockout_until']) - time()) / 60);
        echo json_encode(['success'=>false,'message'=>"Account locked. Try again in $mins minute(s)."]); exit;
    }

    if (!password_verify($password, $user['password'])) {
        $fails = $user['failed_logins'] + 1;
        $lock  = $fails >= 5 ? ", lockout_until=DATE_ADD(NOW(), INTERVAL 15 MINUTE)" : "";
        $conn->query("UPDATE users SET failed_logins=$fails$lock WHERE id={$user['id']}");
        $remaining = max(0, 5 - $fails);
        echo json_encode(['success'=>false,'message'=>"Invalid credentials. $remaining attempt(s) left."]); exit;
    }

    // Reset failed logins
    $conn->query("UPDATE users SET failed_logins=0, lockout_until=NULL WHERE id={$user['id']}");

    // Set session
    $_SESSION['user_id']   = $user['id'];
    $_SESSION['username']  = $user['username'];
    $_SESSION['role']      = $user['role'];
    $_SESSION['full_name'] = $user['full_name'];

    $conn->query("INSERT INTO audit_logs (user_id,action,details,ip_address) VALUES ({$user['id']},'LOGIN','User logged in','".$_SERVER['REMOTE_ADDR']."')");
    echo json_encode(['success'=>true,'role'=>$user['role'],'message'=>'Login successful.']);
    exit;
}

// ── LOGOUT ────────────────────────────────────────────────
if ($action === 'logout') {
    session_destroy();
    echo json_encode(['success'=>true]);
    exit;
}

// ── SESSION CHECK ─────────────────────────────────────────
if ($action === 'check') {
    if (isset($_SESSION['user_id'])) {
        echo json_encode(['logged_in'=>true,'role'=>$_SESSION['role'],'username'=>$_SESSION['username'],'full_name'=>$_SESSION['full_name']]);
    } else {
        echo json_encode(['logged_in'=>false]);
    }
    exit;
}

echo json_encode(['success'=>false,'message'=>'Unknown action.']);
?>
