<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success'=>false,'message'=>'Not authenticated.']); exit;
    }
}

// ── SCHEDULE VISIT ─────────────────────────────────────────
if ($action === 'schedule_visit') {
    requireLogin();
    $buyer_id  = $_SESSION['user_id'];
    $farmer_id = (int)($_POST['farmer_id'] ?? 0);
    $date      = sanitize($conn, $_POST['visit_date'] ?? '');
    $time      = sanitize($conn, $_POST['visit_time'] ?? '');
    $purpose   = sanitize($conn, $_POST['purpose'] ?? '');
    $group     = (int)($_POST['group_size'] ?? 1);
    $notes     = sanitize($conn, $_POST['notes'] ?? '');

    if (!$farmer_id || !$date || !$time) {
        echo json_encode(['success'=>false,'message'=>'Farmer, date and time are required.']); exit;
    }

    // Check for conflicts
    $conflict = $conn->query("SELECT id FROM farm_visits WHERE farmer_id=$farmer_id AND visit_date='$date' AND visit_time='$time' AND status='approved'");
    if ($conflict->num_rows > 0) {
        echo json_encode(['success'=>false,'message'=>'That time slot is already booked. Please choose another.']); exit;
    }

    $stmt = $conn->prepare("INSERT INTO farm_visits (buyer_id,farmer_id,visit_date,visit_time,purpose,group_size,notes) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("iisssiss", $buyer_id, $farmer_id, $date, $time, $purpose, $group, $notes);
    // Fix type: group_size is int
    $stmt = $conn->prepare("INSERT INTO farm_visits (buyer_id,farmer_id,visit_date,visit_time,purpose,group_size,notes) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("iisssis", $buyer_id, $farmer_id, $date, $time, $purpose, $group, $notes);

    if ($stmt->execute()) {
        echo json_encode(['success'=>true,'message'=>'Visit request sent! Waiting for farmer approval.']);
    } else {
        echo json_encode(['success'=>false,'message'=>'Failed to schedule visit.']);
    }
    exit;
}

// ── GET MY VISITS ──────────────────────────────────────────
if ($action === 'my_visits') {
    requireLogin();
    $uid  = $_SESSION['user_id'];
    $role = $_SESSION['role'];
    $col  = $role === 'buyer' ? 'fv.buyer_id' : 'fv.farmer_id';

    $sql = "SELECT fv.*, ub.full_name AS buyer_name, uf.full_name AS farmer_name, uf.address AS farm_address
            FROM farm_visits fv
            JOIN users ub ON fv.buyer_id=ub.id
            JOIN users uf ON fv.farmer_id=uf.id
            WHERE $col=$uid ORDER BY fv.visit_date DESC";

    $res = $conn->query($sql);
    $visits = [];
    while ($row = $res->fetch_assoc()) $visits[] = $row;
    echo json_encode(['success'=>true,'visits'=>$visits]);
    exit;
}

// ── UPDATE VISIT STATUS ────────────────────────────────────
if ($action === 'update_visit') {
    requireLogin();
    $id     = (int)($_POST['id'] ?? 0);
    $status = sanitize($conn, $_POST['status'] ?? '');
    $uid    = $_SESSION['user_id'];
    $valid  = ['approved','declined','rescheduled','completed'];
    if (!in_array($status, $valid)) { echo json_encode(['success'=>false,'message'=>'Invalid status.']); exit; }
    $conn->query("UPDATE farm_visits SET status='$status' WHERE id=$id AND farmer_id=$uid");
    echo json_encode(['success'=>true,'message'=>'Visit status updated.']);
    exit;
}

// ── SEND MESSAGE ───────────────────────────────────────────
if ($action === 'send_message') {
    requireLogin();
    $sender_id   = $_SESSION['user_id'];
    $receiver_id = (int)($_POST['receiver_id'] ?? 0);
    $message     = sanitize($conn, $_POST['message'] ?? '');

    if (!$receiver_id || !$message) {
        echo json_encode(['success'=>false,'message'=>'Receiver and message required.']); exit;
    }

    $stmt = $conn->prepare("INSERT INTO messages (sender_id,receiver_id,message) VALUES (?,?,?)");
    $stmt->bind_param("iis", $sender_id, $receiver_id, $message);
    if ($stmt->execute()) {
        echo json_encode(['success'=>true,'message'=>'Message sent.']);
    } else {
        echo json_encode(['success'=>false,'message'=>'Failed to send.']);
    }
    exit;
}

// ── GET MESSAGES ───────────────────────────────────────────
if ($action === 'get_messages') {
    requireLogin();
    $uid         = $_SESSION['user_id'];
    $other_id    = (int)($_GET['with'] ?? 0);

    if ($other_id) {
        // Conversation with specific user
        $conn->query("UPDATE messages SET is_read=1 WHERE receiver_id=$uid AND sender_id=$other_id");
        $sql = "SELECT m.*, us.full_name AS sender_name, ur.full_name AS receiver_name
                FROM messages m
                JOIN users us ON m.sender_id=us.id
                JOIN users ur ON m.receiver_id=ur.id
                WHERE (m.sender_id=$uid AND m.receiver_id=$other_id)
                OR (m.sender_id=$other_id AND m.receiver_id=$uid)
                ORDER BY m.created_at ASC";
    } else {
        // All conversations
        $sql = "SELECT m.*, us.full_name AS sender_name, ur.full_name AS receiver_name
                FROM messages m
                JOIN users us ON m.sender_id=us.id
                JOIN users ur ON m.receiver_id=ur.id
                WHERE m.sender_id=$uid OR m.receiver_id=$uid
                ORDER BY m.created_at DESC";
    }

    $res = $conn->query($sql);
    $msgs = [];
    while ($row = $res->fetch_assoc()) $msgs[] = $row;
    echo json_encode(['success'=>true,'messages'=>$msgs]);
    exit;
}

// ── POST ALERT (admin) ─────────────────────────────────────
if ($action === 'post_alert') {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') { echo json_encode(['success'=>false,'message'=>'Admin only.']); exit; }
    $admin_id = $_SESSION['user_id'];
    $title    = sanitize($conn, $_POST['title'] ?? '');
    $message  = sanitize($conn, $_POST['message'] ?? '');
    $type     = in_array($_POST['type'] ?? '', ['weather','pest','market','general']) ? $_POST['type'] : 'general';

    $stmt = $conn->prepare("INSERT INTO alerts (admin_id,title,message,type) VALUES (?,?,?,?)");
    $stmt->bind_param("isss", $admin_id, $title, $message, $type);
    if ($stmt->execute()) {
        echo json_encode(['success'=>true,'message'=>'Alert broadcasted!']);
    } else {
        echo json_encode(['success'=>false,'message'=>'Failed to post alert.']);
    }
    exit;
}

// ── GET ALERTS ─────────────────────────────────────────────
if ($action === 'get_alerts') {
    $res = $conn->query("SELECT a.*, u.full_name AS admin_name FROM alerts a JOIN users u ON a.admin_id=u.id ORDER BY a.created_at DESC LIMIT 20");
    $alerts = [];
    while ($row = $res->fetch_assoc()) $alerts[] = $row;
    echo json_encode(['success'=>true,'alerts'=>$alerts]);
    exit;
}

// ── ADMIN STATS ────────────────────────────────────────────
if ($action === 'admin_stats') {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') { echo json_encode(['success'=>false,'message'=>'Admin only.']); exit; }

    $farmers = $conn->query("SELECT COUNT(*) AS c FROM users WHERE role='farmer'")->fetch_assoc()['c'];
    $buyers  = $conn->query("SELECT COUNT(*) AS c FROM users WHERE role='buyer'")->fetch_assoc()['c'];
    $crops   = $conn->query("SELECT COUNT(*) AS c FROM crops WHERE status='available'")->fetch_assoc()['c'];
    $orders  = $conn->query("SELECT COUNT(*) AS c FROM orders")->fetch_assoc()['c'];
    $revenue = $conn->query("SELECT IFNULL(SUM(total_price),0) AS t FROM orders WHERE status='delivered'")->fetch_assoc()['t'];
    $visits  = $conn->query("SELECT COUNT(*) AS c FROM farm_visits")->fetch_assoc()['c'];

    echo json_encode(['success'=>true,'stats'=>compact('farmers','buyers','crops','orders','revenue','visits')]);
    exit;
}

// ── GET ALL USERS (admin) ──────────────────────────────────
if ($action === 'all_users') {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') { echo json_encode(['success'=>false,'message'=>'Admin only.']); exit; }
    $res = $conn->query("SELECT id,username,full_name,email,role,is_active,gov_id_verified,created_at FROM users ORDER BY created_at DESC");
    $users = [];
    while ($row = $res->fetch_assoc()) $users[] = $row;
    echo json_encode(['success'=>true,'users'=>$users]);
    exit;
}

// ── TOGGLE USER ACTIVE ─────────────────────────────────────
if ($action === 'toggle_user') {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') { echo json_encode(['success'=>false,'message'=>'Admin only.']); exit; }
    $id     = (int)($_POST['id'] ?? 0);
    $active = (int)($_POST['is_active'] ?? 0);
    $conn->query("UPDATE users SET is_active=$active WHERE id=$id");
    echo json_encode(['success'=>true,'message'=>'User status updated.']);
    exit;
}

// ── SUBMIT RATING ──────────────────────────────────────────
if ($action === 'submit_rating') {
    requireLogin();
    $buyer_id  = $_SESSION['user_id'];
    $farmer_id = (int)($_POST['farmer_id'] ?? 0);
    $order_id  = (int)($_POST['order_id'] ?? 0);
    $rating    = (int)($_POST['rating'] ?? 0);
    $review    = sanitize($conn, $_POST['review'] ?? '');

    if ($rating < 1 || $rating > 5) { echo json_encode(['success'=>false,'message'=>'Rating must be 1-5.']); exit; }

    $stmt = $conn->prepare("INSERT INTO ratings (buyer_id,farmer_id,order_id,rating,review) VALUES (?,?,?,?,?)");
    $stmt->bind_param("iiiis", $buyer_id, $farmer_id, $order_id, $rating, $review);
    if ($stmt->execute()) {
        echo json_encode(['success'=>true,'message'=>'Rating submitted!']);
    } else {
        echo json_encode(['success'=>false,'message'=>'Failed.']);
    }
    exit;
}

echo json_encode(['success'=>false,'message'=>'Unknown action.']);
?>
