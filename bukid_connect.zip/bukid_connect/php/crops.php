<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success'=>false,'message'=>'Not authenticated.']); exit;
    }
}

// ── GET ALL CROPS (marketplace) ────────────────────────────
if ($action === 'get_crops') {
    $search   = sanitize($conn, $_GET['search'] ?? '');
    $category = sanitize($conn, $_GET['category'] ?? '');
    $where    = "c.status IN ('available','pre-order')";
    if ($search)   $where .= " AND (c.crop_name LIKE '%$search%' OR c.location LIKE '%$search%')";
    if ($category) $where .= " AND c.category='$category'";

    $sql = "SELECT c.*, u.full_name AS farmer_name, u.gov_id_verified,
            IFNULL(ROUND(AVG(r.rating),1),0) AS avg_rating,
            COUNT(r.id) AS review_count
            FROM crops c
            JOIN users u ON c.farmer_id = u.id
            LEFT JOIN ratings r ON r.farmer_id = c.farmer_id
            WHERE $where
            GROUP BY c.id
            ORDER BY c.created_at DESC";

    $res = $conn->query($sql);
    $crops = [];
    while ($row = $res->fetch_assoc()) $crops[] = $row;
    echo json_encode(['success'=>true,'crops'=>$crops]);
    exit;
}

// ── GET FARMER'S OWN CROPS ─────────────────────────────────
if ($action === 'my_crops') {
    requireLogin();
    $uid = $_SESSION['user_id'];
    $res = $conn->query("SELECT c.*, COUNT(o.id) AS order_count FROM crops c LEFT JOIN orders o ON o.crop_id=c.id WHERE c.farmer_id=$uid GROUP BY c.id ORDER BY c.created_at DESC");
    $crops = [];
    while ($row = $res->fetch_assoc()) $crops[] = $row;
    echo json_encode(['success'=>true,'crops'=>$crops]);
    exit;
}

// ── ADD CROP ───────────────────────────────────────────────
if ($action === 'add_crop') {
    requireLogin();
    if ($_SESSION['role'] !== 'farmer') { echo json_encode(['success'=>false,'message'=>'Farmers only.']); exit; }

    $farmer_id = $_SESSION['user_id'];
    $name     = sanitize($conn, $_POST['crop_name'] ?? '');
    $cat      = sanitize($conn, $_POST['category'] ?? '');
    $desc     = sanitize($conn, $_POST['description'] ?? '');
    $price    = (float)($_POST['price_per_unit'] ?? 0);
    $unit     = sanitize($conn, $_POST['unit'] ?? 'kg');
    $qty      = (float)($_POST['quantity_available'] ?? 0);
    $harvest  = sanitize($conn, $_POST['harvest_date'] ?? '');
    $location = sanitize($conn, $_POST['location'] ?? '');
    $status   = in_array($_POST['status'] ?? '', ['available','pre-order']) ? $_POST['status'] : 'available';

    if (!$name || !$price || !$qty) {
        echo json_encode(['success'=>false,'message'=>'Crop name, price and quantity are required.']); exit;
    }

    $stmt = $conn->prepare("INSERT INTO crops (farmer_id,crop_name,category,description,price_per_unit,unit,quantity_available,harvest_date,location,status) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param("issssdssss", $farmer_id, $name, $cat, $desc, $price, $unit, $qty, $harvest, $location, $status);
    if ($stmt->execute()) {
        echo json_encode(['success'=>true,'message'=>'Crop listed successfully!','id'=>$conn->insert_id]);
    } else {
        echo json_encode(['success'=>false,'message'=>'Failed to add crop.']);
    }
    exit;
}

// ── UPDATE CROP STATUS ─────────────────────────────────────
if ($action === 'update_crop') {
    requireLogin();
    $id     = (int)($_POST['id'] ?? 0);
    $status = sanitize($conn, $_POST['status'] ?? '');
    $uid    = $_SESSION['user_id'];
    $conn->query("UPDATE crops SET status='$status' WHERE id=$id AND farmer_id=$uid");
    echo json_encode(['success'=>true,'message'=>'Crop updated.']);
    exit;
}

// ── DELETE CROP ────────────────────────────────────────────
if ($action === 'delete_crop') {
    requireLogin();
    $id  = (int)($_POST['id'] ?? 0);
    $uid = $_SESSION['user_id'];
    $conn->query("DELETE FROM crops WHERE id=$id AND farmer_id=$uid");
    echo json_encode(['success'=>true,'message'=>'Crop deleted.']);
    exit;
}

echo json_encode(['success'=>false,'message'=>'Unknown action.']);
?>
