# 🌾 BUKID CONNECT — Setup Guide
## Requirements: XAMPP (Apache + MySQL + PHP 7.4+)

---

## 📁 FOLDER STRUCTURE

```
bukid_connect/
├── index.html          ← Main SPA frontend
├── database.sql        ← Run this first in phpMyAdmin
├── README.md           ← This file
└── php/
    ├── db.php          ← Database config
    ├── auth.php        ← Login, Register, Logout, Session
    ├── crops.php       ← Crop listings CRUD
    ├── orders.php      ← Order management
    └── api.php         ← Visits, Messages, Alerts, Admin stats
```

---

## ⚙️ INSTALLATION STEPS

### Step 1 — Copy to XAMPP
Place the entire `bukid_connect` folder inside:
```
C:\xampp\htdocs\bukid_connect\
```

### Step 2 — Start XAMPP
- Open XAMPP Control Panel
- Click **Start** on **Apache** and **MySQL**

### Step 3 — Create Database
1. Open your browser → go to: `http://localhost/phpmyadmin`
2. Click **"New"** in the left sidebar
3. Create database named: `bukid_connect`
4. Select the database, click **"Import"** tab
5. Upload and import: `database.sql`
6. Click **Go** ✅

### Step 4 — Access the App
Open your browser and go to:
```
http://localhost/bukid_connect/
```

---

## 👤 DEFAULT TEST ACCOUNTS

| Role   | Username       | Password        |
|--------|---------------|-----------------|
| Admin  | admin          | (see below)     |
| Farmer | juan_farm      | (see below)     |
| Buyer  | maria_buyer    | (see below)     |

> ⚠️ The passwords stored in `database.sql` use bcrypt. For testing, 
> either register new accounts via the UI, or update the password hash 
> by running this PHP snippet to generate your own bcrypt hash:
```php
echo password_hash('YourPassword123', PASSWORD_BCRYPT);
```
Then update the `users` table in phpMyAdmin.

**Easiest: Just register a new account from the app!**

---

## 🔐 SECURITY FEATURES IMPLEMENTED

| Feature                    | Status |
|---------------------------|--------|
| Password Hashing (BCrypt)  | ✅     |
| SQL Injection Protection   | ✅     |
| Failed Login Detection     | ✅     |
| Account Lockout (5 fails)  | ✅     |
| Role-based Authorization   | ✅     |
| Input Sanitization         | ✅     |
| Session Management         | ✅     |
| Audit Logging              | ✅     |

---

## 🌿 FEATURES BY ROLE

### 🌾 FARMER
- Add/manage crop listings (name, price, qty, harvest date, status)
- View and update incoming orders (pending → confirmed → packed → in_transit → delivered)
- Manage farm visit requests (approve/decline)
- Receive messages from buyers
- View dashboard stats

### 🛒 BUYER  
- Browse marketplace with search + category filter
- Place instant orders or pre-orders
- Schedule farm visits
- Track order status
- Rate and review farmers
- Message farmers directly

### ⚙️ ADMIN
- View platform-wide stats (farmers, buyers, orders, revenue)
- Manage all user accounts (activate/deactivate)
- Monitor all transactions
- Broadcast alerts (weather, pest, market, general)

---

## 🛠 TECH STACK

| Layer     | Technology              |
|-----------|------------------------|
| Frontend  | HTML5, CSS3, Vanilla JS |
| Backend   | PHP 7.4+ (REST-style)   |
| Database  | MySQL via XAMPP         |
| Security  | BCrypt, MySQLi prepared statements |
| Fonts     | Playfair Display + DM Sans (Google Fonts) |

---

## 📞 SUPPORT
Built by: Marco Vergara, Lawrence Vergara, Richard Yap  
Course: IAS, CC, PF
