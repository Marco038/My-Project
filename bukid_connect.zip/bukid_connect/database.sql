-- =============================================
-- BUKID CONNECT DATABASE SCHEMA
-- Run this in phpMyAdmin or MySQL CLI
-- =============================================

CREATE DATABASE IF NOT EXISTS bukid_connect CHARACTER SET utf8 COLLATE utf8_general_ci;
USE bukid_connect;

-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('farmer', 'buyer', 'admin') NOT NULL DEFAULT 'buyer',
    full_name VARCHAR(150),
    phone VARCHAR(20),
    address TEXT,
    profile_photo VARCHAR(255),
    gov_id_verified TINYINT(1) DEFAULT 0,
    otp_code VARCHAR(10),
    otp_expiry DATETIME,
    is_active TINYINT(1) DEFAULT 1,
    failed_logins INT DEFAULT 0,
    lockout_until DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CROPS TABLE
CREATE TABLE IF NOT EXISTS crops (
    id INT AUTO_INCREMENT PRIMARY KEY,
    farmer_id INT NOT NULL,
    crop_name VARCHAR(150) NOT NULL,
    category VARCHAR(100),
    description TEXT,
    price_per_unit DECIMAL(10,2) NOT NULL,
    unit VARCHAR(50) DEFAULT 'kg',
    quantity_available DECIMAL(10,2) NOT NULL,
    harvest_date DATE,
    location VARCHAR(200),
    image VARCHAR(255),
    status ENUM('available', 'pre-order', 'sold_out', 'inactive') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ORDERS TABLE
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT NOT NULL,
    farmer_id INT NOT NULL,
    crop_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    order_type ENUM('instant', 'pre-order') DEFAULT 'instant',
    delivery_type ENUM('pickup', 'delivery') DEFAULT 'pickup',
    delivery_address TEXT,
    status ENUM('pending', 'confirmed', 'packed', 'in_transit', 'delivered', 'cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES users(id),
    FOREIGN KEY (farmer_id) REFERENCES users(id),
    FOREIGN KEY (crop_id) REFERENCES crops(id)
);

-- FARM VISITS TABLE
CREATE TABLE IF NOT EXISTS farm_visits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT NOT NULL,
    farmer_id INT NOT NULL,
    visit_date DATE NOT NULL,
    visit_time TIME NOT NULL,
    purpose VARCHAR(255),
    status ENUM('pending', 'approved', 'declined', 'rescheduled', 'completed') DEFAULT 'pending',
    group_size INT DEFAULT 1,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES users(id),
    FOREIGN KEY (farmer_id) REFERENCES users(id)
);

-- MESSAGES TABLE
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id),
    FOREIGN KEY (receiver_id) REFERENCES users(id)
);

-- RATINGS TABLE
CREATE TABLE IF NOT EXISTS ratings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT NOT NULL,
    farmer_id INT NOT NULL,
    order_id INT,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    review TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES users(id),
    FOREIGN KEY (farmer_id) REFERENCES users(id)
);

-- ALERTS TABLE (Admin broadcasts)
CREATE TABLE IF NOT EXISTS alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('weather', 'pest', 'market', 'general') DEFAULT 'general',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id)
);

-- AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(255),
    details TEXT,
    ip_address VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- DEFAULT ADMIN ACCOUNT (password: Admin@123)
INSERT IGNORE INTO users (username, email, password, role, full_name, is_active, gov_id_verified)
VALUES ('admin', 'admin@bukidconnect.ph', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'System Administrator', 1, 1);

-- SAMPLE FARMER (password: Farmer@123)
INSERT IGNORE INTO users (username, email, password, role, full_name, address, phone, is_active, gov_id_verified)
VALUES ('juan_farm', 'juan@bukidconnect.ph', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'farmer', 'Juan dela Cruz', 'Laguna, Calabarzon', '09123456789', 1, 1);

-- SAMPLE BUYER (password: Buyer@123)
INSERT IGNORE INTO users (username, email, password, role, full_name, address, phone, is_active)
VALUES ('maria_buyer', 'maria@bukidconnect.ph', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer', 'Maria Santos', 'Makati City', '09987654321', 1);
